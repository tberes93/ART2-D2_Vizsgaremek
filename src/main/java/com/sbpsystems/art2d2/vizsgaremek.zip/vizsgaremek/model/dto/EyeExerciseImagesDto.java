package com.sbpsystems.art2d2.vizsgaremek.model.dto;

public class EyeExerciseImagesDto {

	private Long eyeExerciseId;
	private Integer orderNumber;
	private String imgName;

	public EyeExerciseImagesDto() {
	}

	public Long getEyeExerciseId() {
		return eyeExerciseId;
	}

	public void setEyeExerciseId(Long eyeExerciseId) {
		this.eyeExerciseId = eyeExerciseId;
	}

	public Integer getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(Integer orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}
}