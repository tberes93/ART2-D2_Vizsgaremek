package com.sbpsystems.art2d2.vizsgaremek.model.dto;

public class StartExerciseDto {

	private Long userId;

	public StartExerciseDto() {
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
}


