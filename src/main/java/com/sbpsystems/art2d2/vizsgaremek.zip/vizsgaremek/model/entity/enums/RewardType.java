package com.sbpsystems.art2d2.vizsgaremek.model.entity.enums;

public enum RewardType {

	PRACTICEDAYS_REWARD,
	CONSECUTIVEDAYS_REWARD;

}
