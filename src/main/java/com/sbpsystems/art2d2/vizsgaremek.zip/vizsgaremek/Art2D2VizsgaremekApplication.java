package com.sbpsystems.art2d2.vizsgaremek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.sbpsystems.art2d2.vizsgaremek")
public class Art2D2VizsgaremekApplication {

    public static void main(String[] args) {
        SpringApplication.run(Art2D2VizsgaremekApplication.class, args);
    }

}
